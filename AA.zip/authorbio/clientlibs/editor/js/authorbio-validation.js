(function ($, Coral) {
    "use strict";

    var registry = $(window).adaptTo("foundation-registry");

    registry.register("foundation.validation.validator", {
        selector: "[data-validation=authorbio-multifield-validation]",
        validate: function (element) {
            var el = $(element);
            var max = el.data("max-items");
            var min = el.data("min-items");
            var items = el.children("coral-multifield-item").length;

            if (items > max) {
                return "You can add a maximum of " + max + " author(s).";
            }
            if (items < min) {
                return "Please add at least " + min + " author.";
            }
        }
    });

})(jQuery, Coral);
